import os
import json
import urllib.parse
import boto3
import os
import json
import urllib.parse
import boto3
import gnupg

import sys
import subprocess

from pprint import pprint

s3 = boto3.client('s3')

S3_BUCKET = 'suth-incoming-s3-test'

#Reference - https://www.saltycrane.com/blog/2011/10/python-gnupg-gpg-example/

def lambda_handler(event, context):
  
    #print("BEFORE permission change")
    #os.system('chmod -R 755 /tmp')
    #print("AFTER permission change")
    # pip install custom package to /tmp/ and add to path
    #subprocess.call('pip install python-gnupg -t /tmp/ --no-cache-dir'.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    #print("pip install python-gnupg DONE")
    #sys.path.insert(1, '/tmp/')
    #subprocess.call('ls /tmp/'.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    print("Received event: " + json.dumps(event, indent=2))

    try:

        print('Loading function - 20th Jan-430pm')
        
        #PGP Decryption
        #Download FILES from S3 to LAMBDA default /tmp
        source_file_object_key = 'LSG_O5_Coupons_20220614030055.txt.pgp'
        destination_file_object_key = '/tmp/LSG_O5_Coupons_20220614030055.txt.pgp'
        s3.download_file(S3_BUCKET,source_file_object_key,destination_file_object_key)
        print('Files to Decrypt - Downloaded from source S3 into LAMBDA /tmp')
        private_key_object_key = 'privatekey.key'
        private_key_dest_object_key = '/tmp/privatekey.key'
        s3.download_file(S3_BUCKET,private_key_object_key,private_key_dest_object_key)
        print('Private Key File - Downloaded from source S3 into LAMBDA /tmp')
        
        # DO PGP decrypt
        #print (gnupg.__version__)
        #os.system('chmod -R 755 /tmp/python-gnupg')
       
        try:
            gpg = gnupg.GPG(gnupghome='/.gnupg') 
        except TypeError:
            gpg = gnupg.GPG(homedir='/.gnupg', binary='./gpg')
            
        print("PGP Module Initialized") 
        
        #Simple PGP encryption try
        unencrypted_string = 'Who are you? How did you get in my house?'
        encrypted_data = gpg.encrypt(unencrypted_string, 'testgpguser@mydomain.com')
        encrypted_string = str(encrypted_data)
        print ('ok: ', encrypted_data.ok)
        print ('status: ', encrypted_data.status)
        print ('stderr: ', encrypted_data.stderr)
        print ('unencrypted_string: ', unencrypted_string)
        print ('encrypted_string: ', encrypted_string)
      
        print("1.BATCH MODE PGP command line try") 
        os.system('gpg --batch --import privatekey.key')
        print("2.BATCH MODE PGP command worked!") 
        
        key_data = open(private_key_dest_object_key).read()
        priv_key = gpg.import_keys(key_data)
        print("Private Key details are:-")
        pprint(priv_key)
        
        private_listed_keys = gpg.list_keys(True)
        
        
        with open('/tmp/'+source_file_object_key,'rb') as a_file:
            print('Open File for PGP decryption')
            try:
                decrypted_state = gpg.decrypt_file(a_file,passphrase='abc',output='/tmp/decryptedfile.txt')
                print ('Decryption Status: ', decrypted_state.status)
                print ('Decryption Stderr: ', decrypted_state.stderr)
                #print('GPG Encryption completed successfully')
            except Exception as e:
                print("GPG Decrypt exception is..",e)
                
        os.system('ls /tmp')
        return
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(source_file_object_key, S3_BUCKET))
        raise e
